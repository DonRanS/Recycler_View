package com.example.app_recycler_view

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.items_example.view.*

class AdaptorExample(
    private val exampleList: List<Exampleitem>,
    private val listener: OnItemClickListener
) : RecyclerView.Adapter<AdaptorExample.ExampleViewHolder>() {

    //call by reclyer when it time to create the new view holder
    //Only been called few times, one time for each item so newer view holder to scroll
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExampleViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.items_example ,
            parent, false)

        return ExampleViewHolder(itemView)
    }

    //always called in !!Be carefull!!
    override fun onBindViewHolder(holder: ExampleViewHolder, position: Int) {
        val currentItem = exampleList[position]

        //called from viewholder
        holder.imageView.setImageResource(currentItem.imageResource)
        holder.textView1.text = currentItem.text1
        holder.textView2.text = currentItem.text2


        //if(position == 0) {
        //    holder.textView1.setBackgroundColor(Color.YELLOW)
        //} else { }
    }

    override fun getItemCount() = exampleList.size

    inner class ExampleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
    View.OnClickListener{
        val imageView: ImageView = itemView.Image_view
        val textView1: TextView = itemView.text_view_1
        val textView2: TextView = itemView.text_view_2

        init {
            itemView.setOnClickListener(this)
        }

        override fun onClick(v: View?) {
            val position = adapterPosition
            if(position != RecyclerView.NO_POSITION){
                listener.onItemClick(position)

            }
        }
    }

    interface OnItemClickListener {
        fun onItemClick(position: Int)

    }
}