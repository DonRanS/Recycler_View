package com.example.app_recycler_view

// class that will only hold data
data class Exampleitem(val imageResource: Int, var text1: String, var text2: String)

