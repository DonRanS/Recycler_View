package com.example.app_recycler_view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.random.Random

class MainActivity : AppCompatActivity(),AdaptorExample.OnItemClickListener {
    private val exampleList = generateDummyList(500)
    private val adaptor = AdaptorExample(exampleList, this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        Recycler_view.adapter = adaptor
        Recycler_view.layoutManager = LinearLayoutManager(this)
        Recycler_view.setHasFixedSize(true)
    }

    fun insertitem(view: View) {
        val index = Random.nextInt(8)

        val nextitem = Exampleitem(
            R.drawable.ic_android,
            "New item at position $index",
            "Line 2"
        )

        exampleList.add(index, nextitem)
        adaptor.notifyItemInserted(index)

    }
    fun removeitem(view: View) {
        val index = Random.nextInt(8)

        exampleList.removeAt(index)
        adaptor.notifyItemRemoved(index)
    }

    override fun onItemClick(position: Int) {
        Toast.makeText(this, "Item $position clicked", Toast.LENGTH_SHORT).show()
        //Toast.makeText(this, "Item $position clicked", Toast.LENGTH_SHORT).show()
        val clickedItem =exampleList[position]
        clickedItem.text1 = "Clicked"
        adaptor.notifyItemChanged(position)
    }

    private fun generateDummyList(size: Int): ArrayList<Exampleitem>{

        //empty array
        val list = ArrayList<Exampleitem>()

        for(i in 0 until size){
            //altenting the drawable
            val drawable = when(i % 3){
                0 -> R.drawable.ic_android
                1 -> R.drawable.id_10k
                else -> R.drawable.ic_360
            }
            //prints using the constructor
            val item = Exampleitem(drawable, "Item $i", "Line2")
            list += item
        }
        return list
    }


}